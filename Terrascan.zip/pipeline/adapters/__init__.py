"""Dataset-specific retrieval adapters."""
